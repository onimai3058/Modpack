local M = {}

function M.calcSpread(api, num, spread)
    local flag=12/spread
    if (num==0)then return{0,1/flag}
    elseif (num==1)then return{0.951/flag,0.309/flag}
    elseif (num==2)then return{-0.951/flag,0.309/flag}
    elseif (num==3)then return{0.587/flag,-0.809/flag}
    elseif (num>=4)then return{-0.587/flag,-0.809/flag}
    end
end

function M.shoot(api)
    local shoot_delay = api:getScriptParams().shoot_delay * 1000
    local count = 2

    if (api:getAimingProgress() > 0) then
        api:safeAsyncTask(function ()
            for i = 1, (api:getAimingProgress()/1 * count) do
                api:shootOnce(i == 1)
            end
            return false
        end,10000,0,1)
        api:adjustShootInterval(api:getShootInterval() + 200)
    else
        api:shootOnce(api:isShootingNeedConsumeAmmo())
    end
end

return M