local M = {}

function M.shoot(api)
        if(api:getFireMode() == BURST)then
            api:shootOnce(api:isShootingNeedConsumeAmmo())
        end
    if(api:getFireMode() == AUTO)then
        api:shootOnce(api:isShootingNeedConsumeAmmo())
        api:removeAmmoFromMagazine(1)
    end
end

return M