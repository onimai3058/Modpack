local M = {}

function M.shoot(api)
    if(api:getFireMode() == BURST)then
        api:safeAsyncTask(function ()
            api:shootOnce(api:isShootingNeedConsumeAmmo())
            return false
        end,1*10000,0,1)
    end
    if(api:getFireMode() == SEMI)then
        api:shootOnce(api:isShootingNeedConsumeAmmo())
    end
end

return M